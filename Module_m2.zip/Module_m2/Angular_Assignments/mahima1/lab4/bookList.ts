export class bookList{
    name:string
    id:number


}