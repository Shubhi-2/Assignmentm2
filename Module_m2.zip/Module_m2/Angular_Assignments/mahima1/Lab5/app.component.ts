import { Component } from '@angular/core';
import{ReactiveFormsModule,FormBuilder,FormGroup,Validators} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

 import{BrowserAnimationsModule} from '@angular/platform-browser/animations';
 import { MatSortModule} from '@angular/material/sort';
 import { MatTableModule} from '@angular/material/table';

import { MyServiceService } from './my-service.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import movies from  './_files/movies.json';
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'MyFirstProject';
 
  public movieList:{id:number,name:string, type:string}[] = movies;
  UId:string;
  ID:string;
 /* constructor (private httpService: HttpClient) { }
  arrBirds: string [];*/
 constructor(private myServiceservice:MyServiceService)
 {

 }





 /*ngOnInit () {
  this.httpService.get('./assets/birds.json').subscribe(
    data => {
      this.arrBirds = data as string [];	 // FILL THE ARRAY WITH DATA.
      //  console.log(this.arrBirds[1]);
    },
    (err: HttpErrorResponse) => {
      console.log (err.message);
    }
  );
}*/
  cost:number;
  t1:string;
  product:string;
  check:boolean;
  namesArray=['Wakeupearly','Attendthe class','Do the assignment','Again attend the class'];
  name1:string;
  data:number=1234;
  ENAME:string;
  SAL:number;
  DEP:string;
  EID:string;
  pipedDataString:string="Dont judge a book by its cover";
  eid:string;
  ename:string;
  sal:number;
  dep:string;
  //name:string;
  id1:number;
  id3:number;
  name3:string;
  type3:string;
  id:number;
  name:string;
  type:string

  
  stringDataForPipe:string="SO HERE COMES THE END OF NAVRATRA..WISHING YOU A ALL HAPPY RAM NAVMI";
    Employee=[
    {
      EID: "101",
      ENAME: "Rahul",
      SAL: 90000,
      DEP: "MBA"
    },
    {
      EID: "102",
      ENAME: "Jatin",
      SAL: 190000,
      DEP: "ACCOUNTS"
    },
    {
      EID: "103",
      ENAME: "PRATIK",
      SAL: 390000,
      DEP: "ELECTRICALS"
    }
  ];
 
/*displaydata(){
  alert("Inside the display of file operations");
  this.myServiceservice.add();
  this.myServiceservice.append();
  this.myServiceservice.delete();
  this.myServiceservice.retrieve();}*/

  displaydata(){
    this.myServiceservice.OnId(this.id1);
    this.id3=this.myServiceservice.id2;
    this.name3=this.myServiceservice.name2;
    this.type3=this.myServiceservice.type2;}
    addNames1(){
     

      
    }
 
  addNames(){

    this.namesArray.push(this.name1);
    console.log(this.namesArray);
  }
  displayName(name:string)
  {
    alert("The message conveyed to all is:"+name);


  }
  addDetails() {
    //prompt("Checking the control!");
    this.Employee.push({
        EID: this.EID,
        ENAME: this.ENAME,
        SAL:this.SAL,
        DEP:this.DEP
        
    });
}
deleteEmployee(index) {
alert("Data deleted");
  this.Employee.splice(index, 1);
}

editEmployee() {

  
 alert("The data has been updated .............)");

 for(let i=0; i<this.Employee.length; i++)
 {
   if(this.Employee[i].EID==this.eid)
   {
    this.Employee.splice(i, 1);
    this.Employee.push({
      EID: this.eid,
      ENAME: this.ename,
      SAL:this.sal,
      DEP:this.dep
      
  });
  break;

   }

 }
 
}
getSortOrder(prop){
  return function(a,b)
  {
    alert(a[prop]+"  "+b[prop])
    if(a[prop]>b[prop])
  
  return 1;
  else if(a[prop]<b[prop])
  return -1

  return 0;
}
}
  



}