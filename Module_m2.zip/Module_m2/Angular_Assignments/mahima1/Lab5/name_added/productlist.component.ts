import { Component, OnInit } from '@angular/core';
import{Product} from '../Product';
import{ ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
productList:Product[]=
[{productId:101 ,productName:'PHONE',productCost:2800},
{productId:103 ,productName:'ASUS',productCost:1800},
{productId:102 ,productName:'MOTOROLA',productCost:800}
]
id:number;
  constructor(private route:ActivatedRoute) {
    route.params.subscribe(params =>{this.id=params['id'];});
    if(this.id!=undefined)
    {
      let id=this.id;
      this.productList=this.productList.filter(function(user)
      {
        return user.productId == id;
      });
    }
   }

  ngOnInit(): void {
  }
  nameSort()
  {
    this.productList.sort(function(a, b){
      var nameA=a.productName.toLowerCase(), nameB=b.productName.toLowerCase()
      if (nameA < nameB) //sort string ascending
          return -1 
      if (nameA > nameB)
          return 1
      return 0 //default return value (no sorting)
  })
  }
  idSort()
  {
    this.productList.sort(function(a, b){
      return a.productId-b.productId
  })
  }
  costSort()
  {
    this.productList.sort(function(a, b){
      return a.productCost-b.productCost
  })
  }

}
