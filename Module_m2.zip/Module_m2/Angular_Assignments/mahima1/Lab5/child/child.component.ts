import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  //@Input() namesList:string[];
  
  
  @Output() outputObj=new EventEmitter();
  data:string="A new day a new start";
  constructor() { }

  ngOnInit(): void {
  }
 /* sendData()
  {
    this.outputObj.emit(this.data);
  }*/

}
